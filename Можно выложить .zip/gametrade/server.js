require('dotenv').config();

const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const db = require('./db');
const { checkMessage, checkPhoneSplitting, hasSuspiciousDigitRun } = require('./lib/messageFilter');
const { reviewPossiblePhoneSplit } = require('./lib/aiModeration');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: 'gametrade-dev-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }, // 7 дней
}));

// Подгружаем текущего пользователя во все шаблоны
app.use((req, res, next) => {
  if (req.session.userId) {
    res.locals.currentUser = db.prepare('SELECT id, username, display_name, rating, deals_count FROM users WHERE id = ?').get(req.session.userId);
  } else {
    res.locals.currentUser = null;
  }
  next();
});

function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.redirect('/login?next=' + encodeURIComponent(req.originalUrl));
  }
  next();
}

function getCategories() {
  return db.prepare('SELECT * FROM categories ORDER BY id').all();
}

function getSalesFeed() {
  return db.prepare('SELECT * FROM sales_feed ORDER BY minutes_ago ASC LIMIT 10').all();
}

const SELLER_JOIN = `
  SELECT p.*, c.name AS category_name, c.slug AS category_slug,
         u.display_name AS seller_name, u.username AS seller_username,
         u.rating AS seller_rating, u.deals_count AS seller_deals
  FROM products p
  JOIN categories c ON p.category_id = c.id
  JOIN users u ON p.seller_id = u.id
`;

// ---------- Каталог ----------
app.get('/', (req, res) => {
  const { category, sort, q, min, max } = req.query;

  let query = SELLER_JOIN + ' WHERE 1=1';
  const params = [];

  if (category) {
    query += ' AND c.slug = ?';
    params.push(category);
  }
  if (q) {
    query += ' AND (p.title LIKE ? OR p.game_name LIKE ?)';
    params.push(`%${q}%`, `%${q}%`);
  }
  if (min) {
    query += ' AND p.price >= ?';
    params.push(Number(min));
  }
  if (max) {
    query += ' AND p.price <= ?';
    params.push(Number(max));
  }

  const sortMap = {
    price_asc: 'p.price ASC',
    price_desc: 'p.price DESC',
    rating: 'u.rating DESC',
    newest: 'p.created_at DESC',
  };
  query += ' ORDER BY ' + (sortMap[sort] || 'p.created_at DESC');

  const products = db.prepare(query).all(...params);

  res.render('catalog', {
    products,
    categories: getCategories(),
    salesFeed: getSalesFeed(),
    activeCategory: category || '',
    activeSort: sort || '',
    q: q || '',
    min: min || '',
    max: max || '',
    productCount: products.length,
  });
});

// ---------- Карточка товара ----------
app.get('/product/:id', (req, res) => {
  const product = db.prepare(SELLER_JOIN + ' WHERE p.id = ?').get(req.params.id);

  if (!product) {
    return res.status(404).render('not-found', { categories: getCategories() });
  }

  const similar = db.prepare(SELLER_JOIN + ' WHERE p.category_id = ? AND p.id != ? ORDER BY RANDOM() LIMIT 4')
    .all(product.category_id, product.id);

  const messages = db.prepare(`
    SELECT m.*, u.display_name AS sender_name
    FROM messages m
    JOIN users u ON u.id = m.sender_id
    WHERE m.product_id = ?
    ORDER BY m.created_at ASC
  `).all(product.id);

  res.render('product', {
    product,
    similar,
    messages,
    categories: getCategories(),
    error: req.query.error || null,
    chatError: req.query.chatError || null,
  });
});

// ---------- Сообщение в чате товара ----------
app.post('/product/:id/message', requireAuth, async (req, res) => {
  const product = db.prepare('SELECT id FROM products WHERE id = ?').get(req.params.id);
  if (!product) {
    return res.status(404).render('not-found', { categories: getCategories() });
  }

  const bodyText = req.body.body;

  // Однозначные случаи (ссылки, названия площадок, мессенджеры) — блокируем сразу, без ИИ
  const singleCheck = checkMessage(bodyText);
  if (singleCheck.blocked) {
    return res.redirect(`/product/${product.id}?chatError=` + encodeURIComponent(singleCheck.reason) + '#chat');
  }

  const recentMessages = db.prepare(`
    SELECT body FROM messages
    WHERE product_id = ? AND sender_id = ? AND created_at >= datetime('now', '-10 minutes')
    ORDER BY created_at ASC
    LIMIT 6
  `).all(product.id, req.session.userId);
  const recentBodies = recentMessages.map(m => m.body);

  // Неоднозначный случай — "похоже на номер по частям". Тут не баним сразу,
  // а отдаём на контекстную проверку ИИ, которая смотрит на смысл переписки,
  // а не просто считает цифры.
  if (hasSuspiciousDigitRun(bodyText, recentBodies)) {
    const aiVerdict = await reviewPossiblePhoneSplit({ recentBodies, newMessage: bodyText });

    if (aiVerdict) {
      if (aiVerdict.blocked) {
        return res.redirect(`/product/${product.id}?chatError=` + encodeURIComponent(aiVerdict.reason) + '#chat');
      }
      // ИИ явно решил, что это не попытка передать контакт — пропускаем дальше
    } else {
      // ИИ недоступен (нет ключа/сбой) — используем резервную эвристику,
      // чтобы не остаться совсем без защиты
      const fallback = checkPhoneSplitting(bodyText, recentBodies);
      if (fallback.blocked) {
        return res.redirect(`/product/${product.id}?chatError=` + encodeURIComponent(fallback.reason) + '#chat');
      }
    }
  }

  db.prepare(`
    INSERT INTO messages (product_id, sender_id, body) VALUES (?, ?, ?)
  `).run(product.id, req.session.userId, bodyText.trim());

  res.redirect(`/product/${product.id}#chat`);
});

// ---------- Покупка ----------
app.post('/product/:id/buy', requireAuth, (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) {
    return res.status(404).render('not-found', { categories: getCategories() });
  }
  if (product.seller_id === req.session.userId) {
    return res.redirect(`/product/${product.id}?error=` + encodeURIComponent('Нельзя купить собственный товар'));
  }
  if (product.stock < 1) {
    return res.redirect(`/product/${product.id}?error=` + encodeURIComponent('Товар закончился'));
  }

  const buyOrder = db.transaction(() => {
    db.prepare('UPDATE products SET stock = stock - 1 WHERE id = ?').run(product.id);
    db.prepare(`
      INSERT INTO orders (product_id, buyer_id, seller_id, product_title, price)
      VALUES (?, ?, ?, ?, ?)
    `).run(product.id, req.session.userId, product.seller_id, product.title, product.price);
    db.prepare('UPDATE users SET deals_count = deals_count + 1 WHERE id = ?').run(product.seller_id);
  });
  buyOrder();

  res.redirect('/profile?tab=purchases');
});

// ---------- Регистрация ----------
app.get('/register', (req, res) => {
  if (req.session.userId) return res.redirect('/profile');
  res.render('register', { categories: getCategories(), error: null, formValues: {} });
});

app.post('/register', (req, res) => {
  const { username, display_name, password, password_confirm } = req.body;

  const fail = (message) => res.render('register', {
    categories: getCategories(),
    error: message,
    formValues: { username, display_name },
  });

  if (!username || !password || !display_name) return fail('Заполните все поля');
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) return fail('Логин: 3–20 символов, латиница/цифры/подчёркивание');
  if (password.length < 6) return fail('Пароль должен быть не короче 6 символов');
  if (password !== password_confirm) return fail('Пароли не совпадают');

  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username.toLowerCase());
  if (existing) return fail('Такой логин уже занят');

  const hash = bcrypt.hashSync(password, 10);
  const info = db.prepare(`
    INSERT INTO users (username, password_hash, display_name) VALUES (?, ?, ?)
  `).run(username.toLowerCase(), hash, display_name);

  req.session.userId = info.lastInsertRowid;
  res.redirect('/profile');
});

// ---------- Вход ----------
app.get('/login', (req, res) => {
  if (req.session.userId) return res.redirect('/profile');
  res.render('login', { categories: getCategories(), error: null, next: req.query.next || '/profile' });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const next = req.body.next || '/profile';
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get((username || '').toLowerCase());

  if (!user || !bcrypt.compareSync(password || '', user.password_hash)) {
    return res.render('login', { categories: getCategories(), error: 'Неверный логин или пароль', next });
  }

  req.session.userId = user.id;
  res.redirect(next);
});

// ---------- Выход ----------
app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

// ---------- Профиль ----------
app.get('/profile', requireAuth, (req, res) => {
  const tab = req.query.tab === 'sales' ? 'sales' : 'purchases';
  const userId = req.session.userId;

  const purchases = db.prepare(`
    SELECT o.*, p.image_seed, p.id AS product_id_live
    FROM orders o
    LEFT JOIN products p ON p.id = o.product_id
    WHERE o.buyer_id = ?
    ORDER BY o.created_at DESC
  `).all(userId);

  const sales = db.prepare(`
    SELECT o.*, p.image_seed, u.display_name AS buyer_name
    FROM orders o
    LEFT JOIN products p ON p.id = o.product_id
    JOIN users u ON u.id = o.buyer_id
    WHERE o.seller_id = ?
    ORDER BY o.created_at DESC
  `).all(userId);

  const myListings = db.prepare(SELLER_JOIN + ' WHERE p.seller_id = ? ORDER BY p.created_at DESC').all(userId);

  res.render('profile', {
    categories: getCategories(),
    tab,
    purchases,
    sales,
    myListings,
    totalSpent: purchases.reduce((sum, o) => sum + o.price, 0),
    totalEarned: sales.reduce((sum, o) => sum + o.price, 0),
  });
});

app.use((req, res) => {
  res.status(404).render('not-found', { categories: getCategories() });
});

app.listen(PORT, () => {
  console.log(`GameTrade запущен: http://localhost:${PORT}`);
});
